package com.springbootdev.amazon.s3.example.aws.config;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;


@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {
	
	
	@Autowired
	private CustomeUserDetailsService customeUserDetailsService;
	
	
	
 
    @Override
    public Authentication authenticate(Authentication authentication) 
      throws AuthenticationException {
    	
    	

    	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    	
    	com.springbootdev.amazon.s3.example.aws.config.UserDetails userDetails = customeUserDetailsService.getUserByUserName("admin");
    	// Json define username and password
    	String encodedPassword=userDetails.getPassword();
    	String encodeUsername=userDetails.getUsername();
    	
       //User define username and password
        String name = authentication.getName();      
        String password1 = authentication.getCredentials().toString();
        System.out.println("BEFORE ENCODE :::"+password1);
       
        System.out.println("encodedPassword::::::::::::::"+ encodedPassword);
        
        // checking user pasword and json password
        
       boolean isPasswordMatch = passwordEncoder.matches(password1, encodedPassword);
		System.out.println("Password : " + password1 + "   isPasswordMatch    : " + isPasswordMatch);
		
		//Condition if user and password checking condition true 
		
       if(name.equalsIgnoreCase(encodeUsername) && passwordEncoder.matches(password1, encodedPassword)==true) {
    	   return new UsernamePasswordAuthenticationToken(name, password1, new ArrayList<>());
    	   
       }
       else {
    	   // else throw error
    	   throw new BadCredentialsException("External system Authentication failed");
    	   
       }
       }
         
        

	@Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }
	
	
}
