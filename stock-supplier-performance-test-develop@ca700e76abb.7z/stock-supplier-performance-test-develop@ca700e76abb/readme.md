## Starter project to create a simple RESTful web service in Kotlin

**Updated for Kotlin 1.3.60 and Ktor 1.2.5**

Companion article: <https://ryanharrison.co.uk/2018/04/14/kotlin-ktor-exposed-starter.html>

### Libraries used:

 - [Ktor](https://github.com/ktorio/ktor) - Kotlin async web framework
 - [Coroutines](https://kotlinlang.org/docs/tutorials/coroutines/coroutines-basic-jvm.html) - support for asynchronous programming builtin in Ktor
 - [Netty](https://github.com/netty/netty) - Async web server
 - [Exposed](https://github.com/JetBrains/Exposed) - Kotlin SQL framework
 - [H2](https://github.com/h2database/h2database) - Embeddable database
 - [HikariCP](https://github.com/brettwooldridge/HikariCP) - High performance JDBC connection pooling
 - [Jackson](https://github.com/FasterXML/jackson) - JSON serialization/deserialization
 - [JUnit 5](https://junit.org/junit5/), [AssertJ](http://joel-costigliola.github.io/assertj/) and [Rest Assured](http://com.ktor.mock.rest-assured.io/) for testing
 
The starter project creates a new H2 database with one table for `Widget` instances.

As ktor is async and based on coroutines, standard blocking JDBC may cause performance issues when used
directly on the main thread pool (as threads must be reused for other requests). Therefore, another dedicated thread
pool is created for all database queries, alongside connection pooling with HikariCP. 

### Useful endpoints

`/ktor-mock/web/trigger-GoodsProvided` - use this endpoint to trigger GoodsProvided events. The events are sent to preconfigured Kafka and topic. 

`/ktor-mock/web/trigger-PackageAllocationDefined` - use this endpoint to trigger PackageAllocationDefined events. 

### Useful commands

`gradlew pushDockerImage helmInstall` - builds docker image and pushes it to vicentral registry. Installs helm chart into team2-cluster. 
Hint: check project.version before installing into the cluster. If the docker image has already been uploaded with the specified version, then increase the version number.
