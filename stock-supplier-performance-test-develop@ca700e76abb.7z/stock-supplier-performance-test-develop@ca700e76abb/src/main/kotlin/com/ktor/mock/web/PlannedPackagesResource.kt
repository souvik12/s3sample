package com.ktor.mock.web

import com.ktor.mock.service.StockRecordService
import com.ktor.mock.web.incoming.PlannedPackage
import com.ktor.mock.web.incoming.PlannedPackageLine
import com.ktor.mock.web.incoming.StockRecord
import io.ktor.application.call
import io.ktor.response.respond
import io.ktor.routing.Route
import io.ktor.routing.get
import io.ktor.routing.route
import java.time.Instant
import java.util.*

fun Route.plannedPackages() {

    route("/planned-packages") {

        get("/{id}") {
            val id = call.parameters["id"]?.toUUID() ?: throw IllegalStateException("Must provide id")
            // determines how many lines supply group will have
            val linesCount = Random().nextInt(6) + 1
            val stockRecords = StockRecordService.getRandomStockRecords(linesCount)
            val plannedPackage = PlannedPackage(id = id,
                                                dispatchDateTime = Instant.now(),
                                                plannedPackageLines = stockRecords?.toPlannedPackageLine())

            call.respond(plannedPackage)
        }
    }

}


fun List<StockRecord>.toPlannedPackageLine(): List<PlannedPackageLine> {
    return this.map { it.toPlannedPackageLine() }
}

fun StockRecord.toPlannedPackageLine() =
        PlannedPackageLine(stockLotId = this.stockLotId,
                            quantityToPack = 1)

private fun String.toUUID() = UUID.fromString(this)
