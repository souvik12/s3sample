package com.ktor.mock.kafka.events

import java.util.*

data class StockRecordsProvided(

        val stockRecordIds: List<UUID>,
        val supplyGroupId: UUID,
        val externalId: UUID,
        val type: String,
        val sourceProcessAreaId: UUID,
        val destinationProcessAreaId: UUID

) : BusinessEvent() {

    override fun getEventKey() = externalId
}
