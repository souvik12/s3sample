package com.ktor.mock.kafka.events

import java.util.*

data class GoodsProvided (

        val itemGroupId: UUID,

        val stockLotId: UUID,

        val quantity: Long,

        val processAreaId: UUID

)  : BusinessEvent() {
    override fun getEventKey() = itemGroupId
}
