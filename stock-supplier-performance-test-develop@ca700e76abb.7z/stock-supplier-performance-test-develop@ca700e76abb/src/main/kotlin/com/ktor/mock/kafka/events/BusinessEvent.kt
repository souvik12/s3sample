package com.ktor.mock.kafka.events

import com.fasterxml.jackson.annotation.JsonIgnore
import java.util.*

abstract class BusinessEvent {

    @JsonIgnore
    abstract fun getEventKey() : UUID

}
