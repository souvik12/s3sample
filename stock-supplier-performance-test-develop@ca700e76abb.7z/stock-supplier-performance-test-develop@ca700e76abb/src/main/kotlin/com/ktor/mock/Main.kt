package com.ktor.mock

import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.ktor.mock.kafka.ConsumerHandler
import com.ktor.mock.kafka.clients.kafka
import com.ktor.mock.service.DatabaseFactory
import com.ktor.mock.web.plannedPackages
import com.ktor.mock.web.supplyGroups
import com.ktor.mock.web.webUI
import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.application.log
import io.ktor.content.TextContent
import io.ktor.features.CallLogging
import io.ktor.features.ContentNegotiation
import io.ktor.features.DefaultHeaders
import io.ktor.http.ContentType
import io.ktor.jackson.jackson
import io.ktor.response.respond
import io.ktor.response.respondText
import io.ktor.routing.Routing
import io.ktor.routing.get
import io.ktor.routing.route
import io.ktor.server.engine.commandLineEnvironment
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.websocket.WebSockets
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import ktor_health_check.Health


@ExperimentalStdlibApi
fun Application.module() {
    install(DefaultHeaders)
    install(CallLogging)
    install(WebSockets)
    install(Health)

    install(ContentNegotiation, configureJackson())

    DatabaseFactory.init()

    val stockSupplierUrl = environment.config.propertyOrNull("ktor.stock-supplier.url")?.getString()
            ?: "http://localhost:8081/stock-supplier"

    val kafkaUrl = environment.config.propertyOrNull("ktor.kafka.url")?.getString() ?: "localhost:9092"
    val topic = environment.config.propertyOrNull("ktor.kafka.topic")?.getString() ?: "systemevent"
    log.info("kafka-url: $kafkaUrl")

    val kafkaConsumerHandler = ConsumerHandler(kafkaUrl, topic, stockSupplierUrl)
    kafka(kafkaUrl) {
        consumer(topic = topic) {
            consume { message ->
                kafkaConsumerHandler.handle(message)
            }
        }
    }

    install(Routing) {

        route("/ktor-mock") {

            route("/api") {

                get("/") {
                    call.respond(TextContent("""
                                                {
                                                    "_links":{
                                                        "stock-supply-groups": {
                                                            "href": "http://localhost:8080/ktor-mock-api/stock-supply-groups"
                                                        },
                                                        "stock-supply-group": {
                                                            "href": "http://localhost:8080/ktor-mock/api/stock-supply-groups/{stockSupplyGroupId}",
                                                            "templated": true
                                                        }
                                                    }
                                                }""".trimIndent(), ContentType.Application.Json))
                }
                supplyGroups()
                plannedPackages()
            }
            webUI(kafkaUrl, topic)
        }

        //REST endpoints for item-inspection-frontend
        get("/mhu-tracker/api/mhus") {
            val carrierId = call.request.queryParameters["physicalId"]
            withContext(Dispatchers.IO) {
                //json file should be an array of json objects
                val jsonText = this.javaClass.classLoader?.getResourceAsStream("json/mhu-items.json")?.readAllBytes()?.decodeToString()!!
                val mhuTrackerJson = JsonParser().parse(jsonText) as JsonArray

                val mhuList = mhuTrackerJson.filter { (it as JsonObject)["mhuId"].asString == carrierId }

                if (mhuList.isNotEmpty()) {
                    call.respondText(mhuList[0].toString(), contentType = ContentType.Application.Json)
                }
            }
        }

        get("/mhu-tracker/api/mhus/{mhuId}/carrier") {
            val mhuId = call.parameters["mhuId"]
            withContext(Dispatchers.IO) {
                //json file should be an array of json objects
                val jsonText = this.javaClass.classLoader?.getResourceAsStream("json/carriers.json")?.readAllBytes()?.decodeToString()!!
                val carriersJson = JsonParser().parse(jsonText) as JsonArray

                val carrier = carriersJson.where { it["mhuId"].asString == mhuId } ?: return@withContext
                call.respondText(carrier.toString(), contentType = ContentType.Application.Json)
            }
        }

        get("/sku-manager/api/sku-variants/{skuVariantId}") {
            val skuVariantId = call.parameters["skuVariantId"]
            withContext(Dispatchers.IO) {
                //json file should be an array of json objects
                val jsonText = this.javaClass.classLoader?.getResourceAsStream("json/sku-variants.json")?.readAllBytes()?.decodeToString()!!
                val skuVariantsJson = JsonParser().parse(jsonText) as JsonArray

                val skuVariant = skuVariantsJson.where { it["id"].asString == skuVariantId }
                skuVariant?.let { call.respondText(skuVariant.toString(), contentType = ContentType.Application.Json) }
            }
        }
    }
}

/**
 * Will return the first result that matches the [condition] from the JsonArray. Null if no element matches the [condition] or the element is not of type JsonObject.
 */
fun JsonArray.where(condition: (JsonObject) -> Boolean): JsonObject? {
    return this.filterIsInstance<JsonObject>().firstOrNull { condition(it) }
}

private fun configureJackson(): ContentNegotiation.Configuration.() -> Unit {
    return {
        jackson {
            configure(SerializationFeature.INDENT_OUTPUT, true)
            registerModule(JavaTimeModule())
//            registerModule(Jdk8Module())
            disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
        }
    }
}

fun main(args: Array<String>) {
    embeddedServer(Netty, commandLineEnvironment(args)).start(wait = true)
}
