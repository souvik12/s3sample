package com.ktor.mock.kafka.events

import java.util.*

data class StockCreated(
        val stockRecordGroupId: UUID,
        val stockRecordId: UUID,
        val stockLotId: UUID,
        val quantity: Long,
        val sourceProcessAreaId: UUID

) : BusinessEvent() {
    override fun getEventKey() = stockRecordId
}
