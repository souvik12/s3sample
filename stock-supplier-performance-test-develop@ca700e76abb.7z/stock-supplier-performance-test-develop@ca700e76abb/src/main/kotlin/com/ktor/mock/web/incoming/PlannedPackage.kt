package com.ktor.mock.web.incoming

import java.time.Instant
import java.util.*

class PlannedPackage (
        val id: UUID,
        val dispatchDateTime: Instant,
        val plannedPackageLines:List<PlannedPackageLine>?
)

class PlannedPackageLine (
    val stockLotId: UUID,
    val quantityToPack: Long
)
