package com.ktor.mock.web.outgoing

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonUnwrapped
import java.util.*

data class StockSupplyGroup(
        val stockSupplyGroupId: UUID,
        val stockOverageId: UUID?,
        val stockDemandId: UUID?,
        val sourceProcessAreaId: UUID,
        val destinationProcessAreaId: UUID,
        @JsonIgnore
        val stockSupplyGroupLines: List<StockSupplyGroupLine>
) {
    @JsonProperty("_embedded")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @JsonUnwrapped
    fun getEmbedded() = stockSupplyGroupLines
}

data class StockSupplyGroupLine(
        val stockSupplyGroupLineId: UUID,
        val stockLotId: UUID,
        val quantity: Long
)
