package com.ktor.mock.service

import com.ktor.mock.model.ItemSupplyGroupLinesTable
import com.ktor.mock.model.ItemSupplyGroupsTable
import com.ktor.mock.model.SupplyGroupLineItemGroupIdsTable
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.select
import com.ktor.mock.web.incoming.ItemSupplyGroup
import com.ktor.mock.web.incoming.ItemSupplyGroupLine
import java.util.*

object ItemSupplyGroupService {

    suspend fun save(itemSupplyGroup: ItemSupplyGroup): ItemSupplyGroup {
        var key: UUID? = null
        DatabaseFactory.dbQuery {
            key = (ItemSupplyGroupsTable.insert {
                it[itemSupplyGroupId] = itemSupplyGroup.itemSupplyGroupId
                it[stockOverageId] = itemSupplyGroup.stockOverageId
                it[externalId] = itemSupplyGroup.externalId
                it[sourceProcessAreaId] = itemSupplyGroup.sourceProcessAreaId
                it[destinationProcessAreaId] = itemSupplyGroup.destinationProcessAreaId
                it[downstreamItemSupplyGroupId] = itemSupplyGroup.downstreamItemSupplyGroupId
            } get ItemSupplyGroupsTable.itemSupplyGroupId)
            itemSupplyGroup.itemSupplyGroupLines?.forEach { itemSupplyGroupLine ->
                ItemSupplyGroupLinesTable.insert {
                    it[itemSupplyGroupLineId] = itemSupplyGroupLine.itemSupplyGroupLineId
                    it[stockLotId] = itemSupplyGroupLine.stockLotId
                    it[quantity] = itemSupplyGroupLine.quantity
                    it[itemSupplyGroupId] = itemSupplyGroup.itemSupplyGroupId
                }
                itemSupplyGroupLine.itemGroupIds.forEach { itemGroup ->
                    itemGroup.let {
                        SupplyGroupLineItemGroupIdsTable.insert {
                            it[itemGroupId] = itemGroup
                            it[itemSupplyGroupLineId] = itemSupplyGroupLine.itemSupplyGroupLineId
                        }
                    }
                }
            }
        }
        return getItemSupplyGroup(key!!)!!
    }

    suspend fun getItemSupplyGroup(id: UUID): ItemSupplyGroup? = DatabaseFactory.dbQuery {
        val itemSupplyGroup = ItemSupplyGroupsTable.select { (ItemSupplyGroupsTable.itemSupplyGroupId eq id) }.firstOrNull()
        val itemSupplyGroupLines = ItemSupplyGroupLinesTable.select { ItemSupplyGroupLinesTable.itemSupplyGroupId eq id }.asIterable()
        val itemGroupIds = SupplyGroupLineItemGroupIdsTable.select { SupplyGroupLineItemGroupIdsTable.itemSupplyGroupLineId eq itemSupplyGroupLines.first()[ItemSupplyGroupLinesTable.itemSupplyGroupLineId]  }.asIterable()

        toItemSupplyGroup(itemSupplyGroup!!, itemSupplyGroupLines, itemGroupIds)
    }

    private fun toItemSupplyGroup(itemSupplyGroup: ResultRow, itemSupplyGroupLinesRows: Iterable<ResultRow>, itemGroupIds: Iterable<ResultRow>): ItemSupplyGroup {

        fun fillItemSupplyGroupLines(itemSupplyGroupLineRows: Iterable<ResultRow>): List<ItemSupplyGroupLine> {
            val itemSupplyGroupLines = mutableListOf<ItemSupplyGroupLine>()
            itemSupplyGroupLineRows.forEach {
                val itemSupplyGroupLineId = it[ItemSupplyGroupLinesTable.itemSupplyGroupLineId]
                val itemSupplyGroupLine = ItemSupplyGroupLine(itemSupplyGroupLineId = it[ItemSupplyGroupLinesTable.itemSupplyGroupId],
                        stockLotId = it[ItemSupplyGroupLinesTable.stockLotId],
                        quantity = it[ItemSupplyGroupLinesTable.quantity],
                        itemGroupIds = itemGroupIds.filter { itemSupplyGroupLineId == it[SupplyGroupLineItemGroupIdsTable.itemSupplyGroupLineId] }
                                                    .map { it[SupplyGroupLineItemGroupIdsTable.itemGroupId] })
                itemSupplyGroupLines.add(itemSupplyGroupLine)
            }
            return itemSupplyGroupLines
        }

        return ItemSupplyGroup(itemSupplyGroupId = itemSupplyGroup[ItemSupplyGroupsTable.itemSupplyGroupId],
                                sourceProcessAreaId = itemSupplyGroup[ItemSupplyGroupsTable.sourceProcessAreaId],
                                destinationProcessAreaId = itemSupplyGroup[ItemSupplyGroupsTable.destinationProcessAreaId],
                                stockDemandId = null,
                                stockOverageId = itemSupplyGroup[ItemSupplyGroupsTable.externalId],
                                returnFlowItemSupplyGroupId = null,
                                externalId = itemSupplyGroup[ItemSupplyGroupsTable.externalId],
                                type = null,
                                downstreamItemSupplyGroupId = itemSupplyGroup[ItemSupplyGroupsTable.downstreamItemSupplyGroupId],
                                itemSupplyGroupLines = fillItemSupplyGroupLines(itemSupplyGroupLinesRows))
    }
}
