package com.ktor.mock.web

import com.fasterxml.jackson.annotation.JsonProperty
import io.ktor.application.call
import io.ktor.http.HttpStatusCode
import io.ktor.response.respond
import io.ktor.routing.Route
import io.ktor.routing.get
import io.ktor.routing.route
import com.ktor.mock.service.StockSupplyGroupService
import com.ktor.mock.web.outgoing.StockSupplyGroup
import com.ktor.mock.web.outgoing.StockSupplyGroupLine
import java.time.Instant
import java.util.*

fun Route.supplyGroups() {

    route("/stock-supply-groups") {

        get("/") {
            StockSupplyGroupService.getAllStockSupplyGroups()?.toResource()?.let{
                call.respond(it)
            }
        }

        get("/{id}") {
            val id = call.parameters["id"]?.toUUID() ?: throw IllegalStateException("Must provide id");
            val supplyGroup = StockSupplyGroupService.getStockSupplyGroup(id)
            if (supplyGroup == null) call.respond(HttpStatusCode.NotFound)
            else call.respond(supplyGroup.toResource())
        }
    }

}

data class StockSupplyGroupResource(val stockSupplyGroupId: UUID,
                                    val externalId: UUID,
                                    val type: String,
                                    val sourceProcessAreaId: UUID,
                                    val destinationProcessAreaId: UUID,
                                    val priority: Instant,
                                    val stockSupplyGroupLines: List<StockSupplyGroupLineResource>) {
}

data class StockSupplyGroupLineResource(val stockSupplyGroupLineId: UUID,
                                        val stockLotId: UUID,
                                        val quantity: Long)

fun List<StockSupplyGroup>.toResource(): List<StockSupplyGroupResource> {
    return this.map { it.toResource() }
}

fun StockSupplyGroup.toResource(): StockSupplyGroupResource {
    fun fillSupplyGroupLines(stockSupplyGroupLines: List<StockSupplyGroupLine>): List<StockSupplyGroupLineResource> {

        val stockSupplyGroupLinesResource = mutableListOf<StockSupplyGroupLineResource>()
        stockSupplyGroupLines.forEach {
            val stockSupplyGroupLineResource = StockSupplyGroupLineResource(stockSupplyGroupLineId = it.stockSupplyGroupLineId,
                    stockLotId = it.stockLotId,
                    quantity = it.quantity)
            stockSupplyGroupLinesResource.add(stockSupplyGroupLineResource)
        }
        return stockSupplyGroupLinesResource
    }

    return StockSupplyGroupResource(stockSupplyGroupId = this.stockSupplyGroupId,
                                    sourceProcessAreaId = this.sourceProcessAreaId,
                                    destinationProcessAreaId = this.destinationProcessAreaId,
                                    priority = Instant.now(),
                                    type = if(stockOverageId != null) {
                                                "STOCK_OVERAGE"
                                           } else {
                                                "STOCK_DEMAND"
                                           },
                                    externalId = this.stockOverageId ?: this.stockDemandId!!,
                                    stockSupplyGroupLines = fillSupplyGroupLines(stockSupplyGroupLines))
}

private fun String.toUUID() = UUID.fromString(this)
