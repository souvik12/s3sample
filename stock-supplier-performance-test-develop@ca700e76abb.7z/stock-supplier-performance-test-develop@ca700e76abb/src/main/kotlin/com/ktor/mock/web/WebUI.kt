package com.ktor.mock.web

import com.ktor.mock.kafka.clients.Kafka
import com.ktor.mock.kafka.clients.Producer
import com.ktor.mock.model.DECANTING_UUID
import com.ktor.mock.model.GTP_UUID
import com.ktor.mock.model.PACKAGE_FINALIZER_UUID
import io.ktor.application.call
import io.ktor.html.respondHtml
import io.ktor.request.receiveParameters
import io.ktor.routing.Route
import io.ktor.routing.get
import io.ktor.routing.post
import io.ktor.routing.route
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.html.*
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import java.util.*

private val log = LoggerFactory.getLogger("com.ktor.mock.web.WebUI")

fun Route.webUI(kafkaUrl: String, topic: String) {

    route("/web") {

        get("/trigger-GoodsProvided") {
            call.respondHtml {
                head {
                    title { +"Trigger GoodsProvided event" }
                }
                body {
                    form(action = "/ktor-mock/web/process-GoodsProvided", method = FormMethod.post) {
                        + "Number of events:"; input(name = "number") {  }; br { }
                        + "Delay in ms between events:"; input(name = "delay") {  }; br { }
                        submitInput { value = "Send event" }
                    }
                }
            }
        }

        post("/process-GoodsProvided") {
            val params = call.receiveParameters()
            val number = params["number"]?.toInt() ?: throw IllegalArgumentException("Number parameter must not be null!")
            val delayNumber = params["delay"]?.toLong() ?: throw IllegalArgumentException("Delay parameter must not be null!")

            val producer = Producer(Kafka(kafkaUrl), topic)

            (1..number).forEach{
                GlobalScope.launch {

                    val uuid = UUID.randomUUID()
                    val itemGroupId = UUID.randomUUID()
                    val stockLotId = UUID.randomUUID()
                    val msg = """{ "id" : "$uuid", "causationId": "$uuid",
                                    | "correlationId" : "$uuid", "name" : "GoodsProvided", "source" : "goods-supplier",
                                    | "timestamp" : "2019-10-17T15:37:52.177661400Z",
                                    | "payload" : { "itemGroupId": "$itemGroupId", 
                                    | "processAreaId": "$DECANTING_UUID",
                                    | "stockLotId": "$stockLotId",
                                    | "quantity": 1000 } }""".trimMargin()
                    producer.send(msg)
                }
                log.info("GoodsProvided No: $it sent")
                delay(delayNumber)
            }

        }

        get("/trigger-PackageAllocationDefined") {
            call.respondHtml {
                head {
                    title { +"Trigger PackageAllocationDefined event" }
                }
                body {
                    form(action = "/ktor-mock/web/process-PackageAllocationDefined", method = FormMethod.post) {
                        + "Number of events:"; input(name = "number") {  }; br { }
                        + "Delay in ms between events:"; input(name = "delay") {  }; br { }
                        submitInput { value = "Send event" }
                    }
                }
            }
        }

        post("/process-PackageAllocationDefined") {
            val params = call.receiveParameters()
            val number = params["number"]?.toInt() ?: throw IllegalArgumentException("Number parameter must not be null!")
            val delayNumber = params["delay"]?.toLong() ?: throw IllegalArgumentException("Delay parameter must not be null!")

            val producer = Producer(Kafka(kafkaUrl), topic)
            val list = mutableListOf<Int>()
            (1..number).forEach{
                GlobalScope.launch {

                    val uuid = UUID.randomUUID()
                    val plannedPackageId = UUID.randomUUID()
                    val msg = """{ "id" : "$uuid", "causationId": "$uuid",
                                    | "correlationId" : "$uuid", "name" : "PackageAllocationDefined", "source" : "package-broker",
                                    | "timestamp" : "2019-10-17T15:37:52.177661400Z",
                                    | "payload" : { "plannedPackageId": "$plannedPackageId", 
                                    | "sourceProcessAreaId": "$GTP_UUID",
                                    | "destinationProcessAreaId": "$PACKAGE_FINALIZER_UUID" } }""".trimMargin()
                    producer.send(msg)
                }
                log.info("PackageAllocationDefined No: $it sent")
                list.add(it)
                delay(delayNumber)
            }
        }
    }

}
