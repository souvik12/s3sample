package com.ktor.mock.model

import org.jetbrains.exposed.sql.Table

object StockSupplyGroupsTable : Table() {
    val stockSupplyGroupId = uuid("id").primaryKey()
    val stockOverageId = uuid("overageId").nullable()
    val stockDemandId = uuid("demandId").nullable()
    val sourceProcessAreaId = uuid("sourceProcessAreaId")
    val destinationProcessAreaId = uuid("destinationProcessAreaId")
}

object StockSupplyGroupLinesTable: Table() {
    val id = uuid("id").primaryKey()
    val stockLotId = uuid("stockLotId")
    val quantity = long("quantity")
    val stockSupplyGroupId = uuid("stockSupplyGroupId").index() references StockSupplyGroupsTable.stockSupplyGroupId
}

object ItemSupplyGroupsTable : Table() {
    val itemSupplyGroupId = uuid("id").primaryKey()
    val sourceProcessAreaId = uuid("sourceProcessAreaId")
    val destinationProcessAreaId = uuid("destinationProcessAreaId")
    val stockOverageId = uuid("overageId").nullable()
    val externalId = uuid("externalId")
    val downstreamItemSupplyGroupId = uuid("downstreamItemSupplyGroupId").nullable()
}

object ItemSupplyGroupLinesTable: Table() {
    val itemSupplyGroupLineId = uuid("id").primaryKey()
    val stockLotId = uuid("stockLotId")
    val quantity = long("quantity")
    val itemSupplyGroupId = uuid("itemSupplyGroupId").index() references ItemSupplyGroupsTable.itemSupplyGroupId
}

object SupplyGroupLineItemGroupIdsTable: Table() {
    val id = long("id").primaryKey().autoIncrement()
    val itemGroupId = uuid("itemGroupId")
    val itemSupplyGroupLineId = uuid("itemSupplyGroupLineId") references ItemSupplyGroupLinesTable.itemSupplyGroupLineId
}

object StockRecordsTable: Table() {
    val stockRecordId = uuid("id").primaryKey()
    val processAreaId = uuid("processAreaId")
    val itemGroupId = uuid("itemGroupId")
    val stockLotId = uuid("stockLotId")
    val quantity = long("quantity")
    val stockRecordStatus = text("stockRecordStatus")
}

object ProcessAreasTable : Table() {
    val processAreaId = uuid("processAreaId").primaryKey()
    val processAreaName = text("processAreaName")
    val processAreaType = text("processAreaType")
    val consumptionAndProvision = text("consumptionAndProvision")
    val processDomainService = text("stock-supplier")
}

object StockOveragesTable : Table() {
    val stockOverageId = uuid("id").primaryKey()
    val sourceProcessAreaId = uuid("sourceProcessAreaId")
}

object OverageLinesTable : Table() {
    val id = uuid("id").primaryKey()
    val stockLotId = uuid("stockLotId")
    val quantity = long("quantity")
    val stockOverageId = uuid("stockOverageId").index() references StockOveragesTable.stockOverageId
}

object StockDemandsTable : Table() {
    val stockDemandId = uuid("id").primaryKey()
    val externalId = uuid("externalId")
    val type = text("type")
    val processAreaId = uuid("processAreaId")
}

object DemandLinesTable : Table() {
    val id = uuid("id").primaryKey()
    val stockLotId = uuid("stockLotId")
    val quantity = long("quantity")
    val stockDemandId = uuid("stockDemandId").index() references StockDemandsTable.stockDemandId
}



