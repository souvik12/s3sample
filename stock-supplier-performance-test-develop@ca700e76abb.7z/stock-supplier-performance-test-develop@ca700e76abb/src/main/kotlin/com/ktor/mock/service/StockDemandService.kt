package com.ktor.mock.service

import com.ktor.mock.model.DemandLinesTable
import com.ktor.mock.model.StockDemandsTable
import com.ktor.mock.web.incoming.DemandLine
import com.ktor.mock.web.incoming.StockDemand
import com.ktor.mock.web.incoming.SupplyGroup
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.select
import java.util.*

object StockDemandService {

    suspend fun addStockDemand(stockDemand: StockDemand): StockDemand {
        var key : UUID? = null
        DatabaseFactory.dbQuery {
            key = (StockDemandsTable.insert {
                it[stockDemandId] = stockDemand.stockDemandId
                it[externalId] = stockDemand.supplyGroup.externalId
                it[type] = stockDemand.supplyGroup.type
                it[processAreaId] = stockDemand.processAreaId
            } get StockDemandsTable.stockDemandId)
        }
        DatabaseFactory.dbQuery {
            stockDemand.stockDemandLines?.forEach {demandLine ->
                DemandLinesTable.insert {
                    it[id] = UUID.randomUUID()
                    it[stockLotId] = demandLine.stockLotId
                    it[quantity] = demandLine.quantity
                    it[stockDemandId] = key!!
                }
            }
        }

        return getStockDemand(key!!)!!
    }

    suspend fun getStockDemand(id: UUID): StockDemand? = DatabaseFactory.dbQuery {
        val demandRow = StockDemandsTable.select { (StockDemandsTable.stockDemandId eq id) }.firstOrNull()
        val demandLineRow = DemandLinesTable.select { (DemandLinesTable.stockDemandId eq id) }.asIterable()

        toStockDemand(demandRow!!, demandLineRow)
    }

    private fun toStockDemand(demandRow: ResultRow, demandLineRow: Iterable<ResultRow>): StockDemand {
        fun fillSupplyGroupLines(demandLineRows: Iterable<ResultRow>) : List<DemandLine>? {
            val demandLines = mutableListOf<DemandLine>()
            demandLineRows.forEach {
                val demandLine = DemandLine(stockLotId = it[DemandLinesTable.stockLotId],
                                                quantity = it[DemandLinesTable.quantity])
                demandLines.add(demandLine)
            }
            return demandLines
        }

        return StockDemand(stockDemandId = demandRow[StockDemandsTable.stockDemandId],
                supplyGroup = SupplyGroup(demandRow[StockDemandsTable.externalId],
                                          demandRow[StockDemandsTable.type]),
                processAreaId = demandRow[StockDemandsTable.processAreaId],
                stockDemandLines = fillSupplyGroupLines(demandLineRow)
        )
    }

}
