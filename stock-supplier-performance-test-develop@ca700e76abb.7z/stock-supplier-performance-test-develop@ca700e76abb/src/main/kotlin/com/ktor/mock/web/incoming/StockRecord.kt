package com.ktor.mock.web.incoming

import java.util.*

class StockRecord(
        val stockRecordId: UUID,
        val itemGroupId: UUID,
        val stockLotId: UUID,
        val quantity: Long,
        val status: String,
        val processAreaId: UUID
)
