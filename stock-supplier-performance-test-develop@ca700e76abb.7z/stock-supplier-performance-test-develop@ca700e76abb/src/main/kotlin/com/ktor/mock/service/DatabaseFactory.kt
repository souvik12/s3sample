package com.ktor.mock.service

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import io.ktor.util.error
import com.ktor.mock.kafka.ConsumerHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.ktor.mock.model.*
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SchemaUtils.create
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.transactions.transaction
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import java.util.*

object DatabaseFactory {

    val log: Logger = LoggerFactory.getLogger(DatabaseFactory::class.java)

    fun init() {
        // Database.connect("jdbc:h2:mem:test;DB_CLOSE_DELAY=-1", driver = "org.h2.Driver")
        Database.connect(hikari())
        transaction {
            create(StockSupplyGroupsTable, StockSupplyGroupLinesTable, ItemSupplyGroupsTable, ItemSupplyGroupLinesTable,
                    SupplyGroupLineItemGroupIdsTable, ProcessAreasTable, StockRecordsTable,
                    StockDemandsTable, DemandLinesTable, StockOveragesTable, OverageLinesTable)
            setupProcessAreas()
        }
    }

    private fun setupProcessAreas() {
        ProcessAreasTable.insert {
            it[processAreaId] = DECANTING_UUID
            it[processAreaName] = "Decanting"
            it[processAreaType] = "Decanting"
            it[consumptionAndProvision] = "coupled"
            it[processDomainService] = "stock-supplier"
        }
        ProcessAreasTable.insert {
            it[processAreaId] = ADAPTO_UUID
            it[processAreaName] = "Adapto Storage"
            it[processAreaType] = "Adapto"
            it[consumptionAndProvision] = "decoupled"
            it[processDomainService] = "stock-supplier"
        }
        ProcessAreasTable.insert {
            it[processAreaId] = GTP_UUID
            it[processAreaName] = "GTP1"
            it[processAreaType] = "GTP"
            it[consumptionAndProvision] = "coupled"
            it[processDomainService] = "stock-supplier"
        }
        ProcessAreasTable.insert {
            it[processAreaId]= PACKAGE_FINALIZER_UUID
            it[processAreaName]= "Package Finalizer"
            it[processAreaType]= "Package Finalizer"
            it[consumptionAndProvision]= "decoupled"
            it[processDomainService]= "Package Finalizer"
        }
    }

    private fun hikari(): HikariDataSource {
        val config = HikariConfig()
        config.driverClassName = "org.h2.Driver"
        config.jdbcUrl = "jdbc:h2:~/app/test"
        config.maximumPoolSize = 3
        config.isAutoCommit = false
        config.transactionIsolation = "TRANSACTION_REPEATABLE_READ"
        config.validate()
        return HikariDataSource(config)
    }

    suspend fun <T> dbQuery(block: () -> T): T? = try{
        withContext(Dispatchers.IO) {
            transaction { block() }
        }
    } catch(e: Exception) {
        log.error(e)
        null
    }

}
