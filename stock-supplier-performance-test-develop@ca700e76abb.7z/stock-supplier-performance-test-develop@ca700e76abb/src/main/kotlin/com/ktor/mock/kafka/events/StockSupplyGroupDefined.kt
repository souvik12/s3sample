package com.ktor.mock.kafka.events

import java.util.*

data class StockSupplyGroupDefined(

        val stockSupplyGroupId: UUID,
        val sourceProcessAreaId: UUID,
        val destinationProcessAreaId: UUID

)  : BusinessEvent() {
    override fun getEventKey() = stockSupplyGroupId
}
