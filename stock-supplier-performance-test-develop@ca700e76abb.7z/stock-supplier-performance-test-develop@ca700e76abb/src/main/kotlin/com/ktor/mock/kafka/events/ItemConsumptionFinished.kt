package com.ktor.mock.kafka.events

import java.util.*

data class ItemConsumptionFinished(val itemSupplyGroupId: UUID) : BusinessEvent() {
    override fun getEventKey(): UUID = itemSupplyGroupId
}
