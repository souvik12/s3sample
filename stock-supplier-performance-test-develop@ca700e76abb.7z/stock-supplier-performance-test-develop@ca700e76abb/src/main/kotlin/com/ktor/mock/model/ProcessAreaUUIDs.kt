package com.ktor.mock.model

import java.util.*

private val String.uuid: UUID
    get() { return UUID.fromString(this)}

val DECANTING_UUID = "440ddf13-c01e-4119-937e-7371863e5441".uuid
val ADAPTO_UUID = "617918a6-b819-11e8-96f8-529269fb1459".uuid
val GTP_UUID = "7b92d218-b819-11e8-96f8-529269fb1459".uuid
val PACKAGE_FINALIZER_UUID = "4e9aa42f-78fb-4b4d-82b8-e98dd3e60b4b".uuid
