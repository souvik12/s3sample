package com.ktor.mock.web.incoming

import com.fasterxml.jackson.annotation.JsonIgnore
import java.util.*


class StockDemand(
        val stockDemandId: UUID,
        val processAreaId: UUID,
        val supplyGroup: SupplyGroup,

        @JsonIgnore
        @property:HalEmbedded
        var stockDemandLines: List<DemandLine>?
)

class DemandLine(
        val stockLotId: UUID,
        val quantity: Long
)

class SupplyGroup(val externalId: UUID, val type: String)
