package com.ktor.mock.web.incoming

import com.fasterxml.jackson.annotation.JsonIgnore
import java.util.*

/**
 * this class is used for incoming REST calls and as internal model class.
 */
data class ItemSupplyGroup(
        val itemSupplyGroupId: UUID,
        val sourceProcessAreaId: UUID,
        val destinationProcessAreaId: UUID,
        val stockDemandId: UUID?,
        val stockOverageId: UUID?,
        val returnFlowItemSupplyGroupId: UUID?,
        val externalId: UUID,
        val type: String?,

        var downstreamItemSupplyGroupId: UUID?,

        @JsonIgnore
        @property:HalEmbedded
        var itemSupplyGroupLines: List<ItemSupplyGroupLine>?
)


data class ItemSupplyGroupLine(
        val itemSupplyGroupLineId: UUID,
        val stockLotId: UUID,
        val quantity: Long,
        val itemGroupIds: List<UUID>
)
