package com.ktor.mock.service

import com.ktor.mock.model.*
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.select
import com.ktor.mock.web.incoming.StockRecord
import org.jetbrains.exposed.sql.Random
import org.jetbrains.exposed.sql.selectAll
import java.util.*

object StockRecordService {

    suspend fun addStockRecord(stockRecord: StockRecord): StockRecord {
        var key: UUID? = null
        DatabaseFactory.dbQuery {
            key = (StockRecordsTable.insert {
                it[stockRecordId] = stockRecord.stockRecordId
                it[processAreaId] = stockRecord.processAreaId
                it[itemGroupId] = stockRecord.itemGroupId
                it[stockLotId] = stockRecord.stockLotId
                it[quantity] = stockRecord.quantity
                it[stockRecordStatus] = stockRecord.status
            } get StockRecordsTable.stockRecordId)
        }
        return getStockRecord(key!!)!!
    }

    suspend fun findByStockLotId(stockLotId: UUID): List<StockRecord> = DatabaseFactory.dbQuery {
        StockRecordsTable.select { StockRecordsTable.stockLotId eq stockLotId}
                .mapNotNull { toStockRecord(it) }
    }!!

    suspend fun getStockRecord(id: UUID): StockRecord? = DatabaseFactory.dbQuery {
        StockRecordsTable.select { (StockRecordsTable.stockRecordId eq id) }
                .mapNotNull { toStockRecord(it) }
                .singleOrNull()
    }

    private fun toStockRecord(row: ResultRow): StockRecord =
            StockRecord(
                    stockRecordId = row[StockRecordsTable.stockRecordId],
                    itemGroupId = row[StockRecordsTable.itemGroupId],
                    stockLotId = row[StockRecordsTable.stockLotId],
                    quantity = row[StockRecordsTable.quantity],
                    status = row[StockRecordsTable.stockRecordStatus],
                    processAreaId = row[StockRecordsTable.processAreaId]
            )

    suspend fun getRandomStockRecords(linesCount: Int) = DatabaseFactory.dbQuery {
        StockRecordsTable.selectAll().orderBy(Random()).limit(linesCount).toList()
                .map { toStockRecord(it) }
    }
}
