package com.ktor.mock.kafka.events

import java.util.*

data class StockOverageDefined (

    val stockOverageId: UUID,

    val sourceProcessAreaId: UUID

)  : BusinessEvent() {
    override fun getEventKey() = stockOverageId
}
