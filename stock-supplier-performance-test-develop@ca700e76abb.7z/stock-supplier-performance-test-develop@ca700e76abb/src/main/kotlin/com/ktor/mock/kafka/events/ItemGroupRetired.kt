package com.ktor.mock.kafka.events

import java.util.*

data class ItemGroupRetired(val itemGroupId: UUID,
                            val retirementReason: String) : BusinessEvent() {
    override fun getEventKey(): UUID = itemGroupId
}
