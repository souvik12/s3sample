package com.ktor.mock.kafka.events

import java.util.*

data class ItemGroupSplit(val processAreaId: UUID, val sourceItemGroupId: UUID,
                          val destinationItemGroupId: UUID, val transferredQuantity: Long) : BusinessEvent() {
    override fun getEventKey() = processAreaId
}
