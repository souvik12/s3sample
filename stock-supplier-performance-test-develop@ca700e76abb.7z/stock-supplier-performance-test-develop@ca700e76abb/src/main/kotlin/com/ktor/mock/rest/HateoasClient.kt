package com.ktor.mock.rest

import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.google.gson.JsonParser
import io.ktor.client.HttpClient
import io.ktor.client.engine.apache.Apache
import io.ktor.client.features.auth.Auth
import io.ktor.client.features.auth.providers.basic
import io.ktor.client.request.forms.submitForm
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.response.HttpResponse
import io.ktor.client.response.readText
import io.ktor.http.parametersOf
import io.ktor.http.plus
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import com.ktor.mock.web.incoming.HalEmbedded
import org.apache.http.ssl.SSLContexts
import java.io.File
import java.lang.System.getProperty
import kotlin.reflect.KMutableProperty
import kotlin.reflect.full.declaredMemberProperties
import kotlin.reflect.full.findAnnotation
import kotlin.reflect.jvm.javaField


class HateoasClient {

    companion object {
        val log: Logger = LoggerFactory.getLogger(HateoasClient::class.java)
    }

    private val httpClient = HttpClient(Apache) {
        expectSuccess = false
        engine {
            customizeClient {
                setSSLContext(
                        SSLContexts
                                .custom()
                                .loadTrustMaterial(
                                        File(getProperty("javax.net.ssl.trustStore")),
                                        getProperty("javax.net.ssl.trustStorePassword").toCharArray())
                                .build())
            }
        }
        install(Auth) {
            basic {
                username = "1"
                password = "gambit"
            }
        }
    }

    private var accessToken: String? = null

    private var authenticationCounter: Int = 0

    suspend fun get(url: String): String {

        accessToken ?: coroutineScope{ accessToken = authenticate() }

        if (authenticationCounter < 3) {
            httpClient.get<HttpResponse>(url) {
                header("Authorization", "Bearer $accessToken")
            }.use { response ->
                val content = response.readText()
                return when (response.status.value) {
                    200 -> {
                        log.info("200: received status code 200")
                        log.info("Content GET Request 200: $content")
                        authenticationCounter = 0
                        content
                    }
                    401 -> {
                        log.info("Content GET Request 401: $content")
                        accessToken = coroutineScope { authenticate() }
                        authenticationCounter++
                        log.info("AccessToken: $accessToken")
                        get(url)
                    }
                    else -> {
                        log.info("Content GET Request else branch: $content")
                        throw Exception("Cannot make a GET request to $url")
                    }
                }
            }

        }

        throw Exception("unable to make get request")
    }

    private suspend fun authenticate(): String {
        val keycloakUrl = "https://team2-vanderlande.westeurope.cloudapp.azure.com/auth/realms/production/protocol/openid-connect/token"
        httpClient.submitForm<HttpResponse>(
                keycloakUrl,
                parametersOf("grant_type", "client_credentials")
                        .plus(parametersOf("client_secret", "92643376-aa96-49ed-95c4-71ad7be1469e"))
                        .plus(parametersOf("client_id", "fm-test-client")),
                false
        ).use { response ->
            when (response.status.value) {
                200 -> {
                    log.info("authenticated")
                    response.status.value
                    val content = response.readText()
                    return JsonParser().parse(content).asJsonObject["access_token"].asString.toString()
                }
                else -> {
                    log.info("${response.status.value}")
                    val content = response.readText()
                    log.info(content)
                    throw Exception("Cannot authenticate against keycloak at $keycloakUrl")
                }
            }
        }
    }

    inline fun <reified T : Any> fetchResource(id: String, relation: String, baseUri: String): T {
        val apiContent = runBlocking { get(baseUri) }
        val hrefForResource = JsonParser().parse(apiContent).asJsonObject["_links"].asJsonObject[relation]
                .asJsonObject["href"].asString.replace(Regex("\\{.*\\}"), id)

        val resource = runBlocking { get(hrefForResource) }

        val mapper = jacksonObjectMapper().apply {
            registerModule(JavaTimeModule())
            disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
        }

        return mapper.convertToHalResource<T>(resource)
    }

    inline fun <reified T : Any> ObjectMapper.convertToHalResource(resource: String): T {
        val genericResource = this.readValue<T>(resource, T::class.java)
        val embedded = JsonParser().parse(resource).asJsonObject["_embedded"]

        T::class.declaredMemberProperties.forEach {
            if (it.findAnnotation<HalEmbedded>() != null) {
                val embeddedArray = embedded.asJsonObject[it.name].toString()

                val genericType = it.javaField?.genericType
                val constructType = this.typeFactory.constructType(genericType)
                val type = constructType.bindings.getBoundType(0).rawClass

                val embeddedElements = this.readValue(embeddedArray, List::class.java)
                val convertedElements = embeddedElements.map {
                    this.convertValue(it, type)
                }
                if (it is KMutableProperty<*>) {
                    it.setter.call(genericResource, convertedElements)
                }
            }
        }
        return genericResource
    }

}
