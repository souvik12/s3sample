package com.ktor.mock.kafka.events

import java.util.*

data class ItemConsumptionPlanned(

        val itemSupplyGroupId: UUID,

        val destinationProcessAreaId: UUID

)  : BusinessEvent() {
    override fun getEventKey(): UUID = itemSupplyGroupId
}
