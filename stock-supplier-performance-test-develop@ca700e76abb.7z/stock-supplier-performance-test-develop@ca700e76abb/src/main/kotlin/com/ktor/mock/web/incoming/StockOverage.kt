package com.ktor.mock.web.incoming

import com.fasterxml.jackson.annotation.JsonIgnore
import java.util.*

/**
 * This annotation is designed to be used for _embedded elements on DTOs for incoming responses, whose content type corresponds to hal+json,
 * because Jackson library does not support unmarshalling for _embedded elements out of the box.
 *
 * Use this for properties like this: @property:HalEmbedded
 */
@Target(AnnotationTarget.PROPERTY)
annotation class HalEmbedded

class StockOverage(
        val stockOverageId: UUID,
        val sourceProcessAreaId: UUID,

        @JsonIgnore
        @property:HalEmbedded
        var stockOverageLines: List<OverageLine>?
)

class OverageLine(
        val stockLotId: UUID,
        val quantity: Long
)
