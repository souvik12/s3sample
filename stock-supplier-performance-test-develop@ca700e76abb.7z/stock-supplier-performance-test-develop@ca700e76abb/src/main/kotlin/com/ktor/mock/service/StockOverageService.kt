package com.ktor.mock.service

import com.ktor.mock.model.OverageLinesTable
import com.ktor.mock.model.StockOveragesTable
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.select
import com.ktor.mock.web.incoming.OverageLine
import com.ktor.mock.web.incoming.StockOverage
import java.util.*

object StockOverageService {

    suspend fun addStockOverage(stockOverage: StockOverage): StockOverage {
        var key : UUID? = null
        DatabaseFactory.dbQuery {
            key = (StockOveragesTable.insert {
                it[stockOverageId] = stockOverage.stockOverageId
                it[sourceProcessAreaId] = stockOverage.sourceProcessAreaId
            } get StockOveragesTable.stockOverageId)
        }
        DatabaseFactory.dbQuery {
            stockOverage.stockOverageLines?.forEach {overageLine ->
                OverageLinesTable.insert {
                    it[id] = UUID.randomUUID()
                    it[stockLotId] = overageLine.stockLotId
                    it[quantity] = overageLine.quantity
                    it[stockOverageId] = key!!
                }
            }
        }

        return getStockOverage(key!!)!!
    }

    suspend fun getStockOverage(id: UUID): StockOverage? = DatabaseFactory.dbQuery {
        val overageRow = StockOveragesTable.select { (StockOveragesTable.stockOverageId eq id) }.firstOrNull()
        val overageLineRow = OverageLinesTable.select { (OverageLinesTable.stockOverageId eq id) }.asIterable()

        toStockOverage(overageRow!!, overageLineRow)
    }

    private fun toStockOverage(overageRow: ResultRow, overageLineRow: Iterable<ResultRow>): StockOverage {
        fun fillSupplyGroupLines(overageLineRows: Iterable<ResultRow>) : List<OverageLine>? {
            val overageLines = mutableListOf<OverageLine>()
            overageLineRows.forEach {
                val overageLine = OverageLine(stockLotId = it[OverageLinesTable.stockLotId],
                                                quantity = it[OverageLinesTable.quantity])
                overageLines.add(overageLine)
            }
            return overageLines
        }

        return StockOverage(stockOverageId = overageRow[StockOveragesTable.stockOverageId],
                sourceProcessAreaId = overageRow[StockOveragesTable.sourceProcessAreaId],
                stockOverageLines = fillSupplyGroupLines(overageLineRow)
        )
    }




}
