package com.ktor.mock.kafka.events

import java.util.*

data class PackageAllocationDefined (

        val plannedPackageId: UUID,

        val sourceProcessAreaId: UUID,

        val destinationProcessAreaId: UUID

)  : BusinessEvent() {
    override fun getEventKey() = plannedPackageId
}
