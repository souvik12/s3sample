package com.ktor.mock.kafka.events

import java.util.*

data class ItemsConsumed (

    val itemSupplyGroupId: UUID,
    val destinationProcessAreaId: UUID,
    val itemGroupIds: List<UUID>

) : BusinessEvent() {

    override fun getEventKey() = itemSupplyGroupId
}
