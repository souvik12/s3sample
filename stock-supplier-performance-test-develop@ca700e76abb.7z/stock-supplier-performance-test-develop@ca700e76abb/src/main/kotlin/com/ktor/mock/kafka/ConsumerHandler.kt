package com.ktor.mock.kafka

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.convertValue
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.ktor.mock.kafka.clients.Kafka
import com.ktor.mock.kafka.clients.Producer
import com.ktor.mock.kafka.events.*
import com.ktor.mock.model.ADAPTO_UUID
import com.ktor.mock.model.DECANTING_UUID
import com.ktor.mock.model.GTP_UUID
import com.ktor.mock.rest.HateoasClient
import com.ktor.mock.service.*
import com.ktor.mock.web.incoming.ItemSupplyGroup
import com.ktor.mock.web.incoming.StockDemand
import com.ktor.mock.web.incoming.StockOverage
import com.ktor.mock.web.incoming.StockRecord
import com.ktor.mock.web.outgoing.StockSupplyGroup
import com.ktor.mock.web.outgoing.StockSupplyGroupLine
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import java.util.*


class ConsumerHandler(private val kafkaUrl: String,
                      private val topic: String,
                      private val stockSupplierUrl: String) {

    private val mapper = jacksonObjectMapper()

    private var counterGoodsProvided: Int = 0

    private val hateoasClient = HateoasClient()

    init {
        mapper.registerModule(JavaTimeModule())
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
    }

    private val kafkaProducer = Producer(Kafka(kafkaUrl), topic)

    companion object {
        val log: Logger = LoggerFactory.getLogger(ConsumerHandler::class.java)
    }

    fun handle(message: String) {
        val kafkaEvent = mapper.readValue(message, KafkaEvent::class.java)
        log.info("${kafkaEvent.name}: " + kafkaEvent.payload.toString())


        when (kafkaEvent.name) {
            GoodsProvided::class.simpleName -> {
                log.info("Goods Provided No: ${++counterGoodsProvided}  event since startup")
            }
            StockCreated::class.simpleName -> onStockCreated(kafkaEvent)
            StockOverageDefined::class.simpleName -> onStockOverageDefined(kafkaEvent)
            ItemConsumptionDefined::class.simpleName -> onItemConsumptionDefined(kafkaEvent)
            ItemProvisionOptionsDefined::class.simpleName -> onItemProvisionOptionsDefined(kafkaEvent)
            StockRecordsProvided::class.simpleName -> onStockRecordsProvided(kafkaEvent)
            StockDemandDefined::class.simpleName -> onStockDemandDefined(kafkaEvent)
        }
    }

    private fun onStockCreated(kafkaEvent: KafkaEvent) {
        val (stockRecordGroupId, stockRecordId, stockLotId, quantity, sourceProcessAreaId)
                = convertToBusinessEvent<StockCreated>(kafkaEvent.payload)

        repeat(2) {
            GlobalScope.launch {
                val stockRecord = hateoasClient.fetchResource<StockRecord>("$stockRecordId", "stock-record", "$stockSupplierUrl/api")
                if (it == 0) {
                    StockRecordService.addStockRecord(stockRecord)
                }
            }
        }
    }

    private fun onStockOverageDefined(kafkaEvent: KafkaEvent) {
        val (stockOverageId, sourceProcessAreaId) = convertToBusinessEvent<StockOverageDefined>(kafkaEvent.payload)

        GlobalScope.launch {

            try {
                log.info("fetching stockOverages")
                val stockOverageObj = hateoasClient.fetchResource<StockOverage>("$stockOverageId", "stock-overage", "$stockSupplierUrl/api")
                log.info("stockOverages fetched successfully")
                StockOverageService.addStockOverage(stockOverageObj)

                val supplyGroupLines = mutableListOf<StockSupplyGroupLine>()
                stockOverageObj.stockOverageLines?.forEach {
                    val stockSupplyGroupLine = StockSupplyGroupLine(UUID.randomUUID(), it.stockLotId, it.quantity)
                    supplyGroupLines.add(stockSupplyGroupLine)
                }
                val supplyGroup = StockSupplyGroupService.save(StockSupplyGroup(UUID.randomUUID(), stockOverageId, null, sourceProcessAreaId, ADAPTO_UUID, supplyGroupLines))

                val supplyGroupDefined = StockSupplyGroupDefined(supplyGroup.stockSupplyGroupId, sourceProcessAreaId, ADAPTO_UUID)
                kafkaProducer.send(supplyGroupDefined, kafkaEvent)

            } catch (e: Exception) {
                log.info(e.toString())
                e.printStackTrace()
                log.info("cannot fetch StockOverage from stock-supplier")
            }

        }
    }

    private fun onStockDemandDefined(kafkaEvent: KafkaEvent) {
        val (stockDemandId, _, externalId, type) = convertToBusinessEvent<StockDemandDefined>(kafkaEvent.payload)

        GlobalScope.launch {

            try {
                log.info("fetching stockDemand")
                val stockDemandObj = hateoasClient.fetchResource<StockDemand>("$stockDemandId", "stock-demand", "$stockSupplierUrl/api")
                log.info("stockDemand fetched successfully")
                StockDemandService.addStockDemand(stockDemandObj)

                val supplyGroupLines = mutableListOf<StockSupplyGroupLine>()
                stockDemandObj.stockDemandLines?.forEach {
                    val stockSupplyGroupLine = StockSupplyGroupLine(UUID.randomUUID(), it.stockLotId, it.quantity)
                    supplyGroupLines.add(stockSupplyGroupLine)
                }
                val sourceProcessAreaId = stockDemandObj.processAreaId
//                val destinationProcessAreaId = stockDemandObj.destinationProcessAreaId
                val supplyGroup = StockSupplyGroupService.save(StockSupplyGroup(UUID.randomUUID(), null, stockDemandId, ADAPTO_UUID, GTP_UUID, supplyGroupLines))

                val supplyGroupDefined = StockSupplyGroupDefined(supplyGroup.stockSupplyGroupId, ADAPTO_UUID, GTP_UUID)
                kafkaProducer.send(supplyGroupDefined, kafkaEvent)

            } catch (e: Exception) {
                log.info(e.toString())
                e.printStackTrace()
                log.info("cannot fetch StockDemand from stock-supplier")
            }
        }
    }

    private fun onItemConsumptionDefined(kafkaEvent: KafkaEvent) {
        val (itemSupplyGroupId, destinationProcessArea, downstreamItemSupplyGroupId) = convertToBusinessEvent<ItemConsumptionDefined>(kafkaEvent.payload)

        GlobalScope.launch {
            val itemSupplyGroupObj = hateoasClient.fetchResource<ItemSupplyGroup>("$itemSupplyGroupId", "item-supply-group", "$stockSupplierUrl/api")
            itemSupplyGroupObj.downstreamItemSupplyGroupId = downstreamItemSupplyGroupId

            //TODO: To save or not to save?
            ItemSupplyGroupService.save(itemSupplyGroupObj)
            log.info("$itemSupplyGroupObj")

            val itemConsumptionPlanned = ItemConsumptionPlanned(itemSupplyGroupId, destinationProcessArea)
            kafkaProducer.send(itemConsumptionPlanned, kafkaEvent)
        }
    }

    private fun onItemProvisionOptionsDefined(kafkaEvent: KafkaEvent) {
        val (itemSupplyGroupId, sourceProcessAreaId) = convertToBusinessEvent<ItemProvisionOptionsDefined>(kafkaEvent.payload)

        val itemGroups = mutableListOf<List<UUID>>()
        GlobalScope.launch {
            val itemSupplyGroupObj = hateoasClient.fetchResource<ItemSupplyGroup>("$itemSupplyGroupId", "item-supply-group", "$stockSupplierUrl/api")

            itemSupplyGroupObj.itemSupplyGroupLines?.forEach {
                if(sourceProcessAreaId == DECANTING_UUID) {
                    itemGroups.add(it.itemGroupIds)

                    val itemsConsumed = ItemsConsumed(itemSupplyGroupId, itemSupplyGroupObj.destinationProcessAreaId, it.itemGroupIds)
                    kafkaProducer.send(itemsConsumed, kafkaEvent)
                } else if(sourceProcessAreaId == ADAPTO_UUID) {
                    //TODO more than one ItemsConsumed per StockLotId (include multiple stockRecords with same StockLotId)
                    val itemGroupIds = StockRecordService.findByStockLotId(it.stockLotId).map { it.itemGroupId }
//                    itemGroups.add(itemGroupIds)

                    val itemsConsumed = ItemsConsumed(itemSupplyGroupId, itemSupplyGroupObj.destinationProcessAreaId, itemGroupIds)
                    kafkaProducer.send(itemsConsumed, kafkaEvent)

                    val newItemGroupId = UUID.randomUUID()
                    itemGroups.add(listOf(newItemGroupId))
                    val itemGroupSplit = ItemGroupSplit(GTP_UUID, itemGroupIds[0], newItemGroupId, 1)
                    kafkaProducer.send(itemGroupSplit, kafkaEvent)

                    val itemConsumedToAdapto = ItemsConsumed(itemSupplyGroupObj.returnFlowItemSupplyGroupId!!, ADAPTO_UUID, itemGroupIds)
                    kafkaProducer.send(itemConsumedToAdapto, kafkaEvent)
                }
            }
            val itemConsumptionFinished = ItemConsumptionFinished(itemSupplyGroupId)
            kafkaProducer.send(itemConsumptionFinished, kafkaEvent)

            if(sourceProcessAreaId == ADAPTO_UUID) {
                ItemSupplyGroupService.getItemSupplyGroup(itemSupplyGroupId)?.let {
                    ItemSupplyGroupService.getItemSupplyGroup(it.downstreamItemSupplyGroupId!!)?.let {
                        val itemsConsumedToPAF = ItemsConsumed(it.itemSupplyGroupId, it.destinationProcessAreaId, itemGroups.flatten())
                        kafkaProducer.send(itemsConsumedToPAF, kafkaEvent)

                        val itemConsumptionFinishedToPAF = ItemConsumptionFinished(it.itemSupplyGroupId)
                        kafkaProducer.send(itemConsumptionFinishedToPAF, kafkaEvent)

                        itemGroups.flatten().forEach {
                            val itemGroupRetired = ItemGroupRetired(it, "Packed")
                            kafkaProducer.send(itemGroupRetired, kafkaEvent)
                        }
                    }
                }
            }
        }
    }

    private fun onStockRecordsProvided(kafkaEvent: KafkaEvent) {
        val (stockRecords) = convertToBusinessEvent<StockRecordsProvided>(kafkaEvent.payload)

        stockRecords.forEach {
            GlobalScope.launch { hateoasClient.fetchResource<StockRecord>("$it", "stock-record", "$stockSupplierUrl/api") }
        }
    }

    private inline fun <reified T : BusinessEvent> convertToKafkaEvent(businessEvent: T, kafkaEvent: KafkaEvent): String {
        val event = KafkaEvent(id = UUID.randomUUID(), causationId = kafkaEvent.id, correlationId = kafkaEvent.correlationId,
                name = T::class.simpleName!!, source = "stock-broker",
                payload = mapper.convertValue(businessEvent, object : TypeReference<Map<String, Any>>() {}))

        return mapper.writeValueAsString(event)
    }

    private inline fun <reified T> convertToBusinessEvent(payload: Map<String, Any>): T {
        return mapper.convertValue<T>(payload)
    }

    private inline fun <reified T : BusinessEvent> Producer.send(businessEvent: T, event: KafkaEvent) {
        val jsonOutput = convertToKafkaEvent(businessEvent, event)
        this.send(jsonOutput)
    }

}
