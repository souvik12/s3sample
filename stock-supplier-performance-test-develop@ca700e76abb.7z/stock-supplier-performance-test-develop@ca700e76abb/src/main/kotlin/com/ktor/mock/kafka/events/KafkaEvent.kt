package com.ktor.mock.kafka.events

import java.time.Instant
import java.util.*


data class KafkaEvent (
        val id: UUID,
        val causationId: UUID?,
        val correlationId: UUID?,
        val name: String,
        val source: String,
        val timestamp: Instant = Instant.now(),
        val payload: MutableMap<String, Any>
)
