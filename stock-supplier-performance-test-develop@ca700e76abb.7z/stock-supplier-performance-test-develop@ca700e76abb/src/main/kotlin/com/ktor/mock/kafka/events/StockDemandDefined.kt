package com.ktor.mock.kafka.events

import java.util.*

data class StockDemandDefined(
        val stockDemandId: UUID,
        val sourceProcessAreaId: UUID,
        val externalId: UUID,
        val type: String
) : BusinessEvent() {
    override fun getEventKey() = stockDemandId
}
