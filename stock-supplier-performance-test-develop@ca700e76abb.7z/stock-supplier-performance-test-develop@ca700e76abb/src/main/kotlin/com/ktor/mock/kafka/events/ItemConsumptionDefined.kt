package com.ktor.mock.kafka.events

import java.util.*

data class ItemConsumptionDefined(

        val itemSupplyGroupId: UUID,
        val destinationProcessAreaId: UUID,
        val downstreamItemSupplyGroupId: UUID

        ) : BusinessEvent() {
    override fun getEventKey() = itemSupplyGroupId


}
