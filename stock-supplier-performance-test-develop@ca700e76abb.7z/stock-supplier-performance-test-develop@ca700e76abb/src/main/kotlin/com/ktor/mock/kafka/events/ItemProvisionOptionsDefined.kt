package com.ktor.mock.kafka.events

import java.util.*

data class ItemProvisionOptionsDefined(

        val itemSupplyGroupId: UUID,

        val sourceProcessAreaId: UUID

)  : BusinessEvent() {
    override fun getEventKey() = itemSupplyGroupId
}
