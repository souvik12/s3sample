package com.ktor.mock.service

import com.ktor.mock.model.StockSupplyGroupLinesTable
import com.ktor.mock.model.StockSupplyGroupsTable
import com.ktor.mock.service.DatabaseFactory.dbQuery
import com.ktor.mock.web.outgoing.StockSupplyGroup
import com.ktor.mock.web.outgoing.StockSupplyGroupLine
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.select
import org.jetbrains.exposed.sql.selectAll
import java.util.*

object StockSupplyGroupService {

    suspend fun save(stockSupplyGroup: StockSupplyGroup): StockSupplyGroup {
        var key : UUID? = null
        dbQuery {
            key = (StockSupplyGroupsTable.insert {
                it[stockSupplyGroupId] = stockSupplyGroup.stockSupplyGroupId
                it[stockOverageId] = stockSupplyGroup.stockOverageId
                it[stockDemandId] = stockSupplyGroup.stockDemandId
                it[sourceProcessAreaId] = stockSupplyGroup.sourceProcessAreaId
                it[destinationProcessAreaId] = stockSupplyGroup.destinationProcessAreaId
            } get StockSupplyGroupsTable.stockSupplyGroupId)
        }
        dbQuery {
            stockSupplyGroup.stockSupplyGroupLines.forEach { stockSupplyGroupLine ->
                StockSupplyGroupLinesTable.insert {
                    it[id] = stockSupplyGroupLine.stockSupplyGroupLineId
                    it[stockLotId] = stockSupplyGroupLine.stockLotId
                    it[quantity] = stockSupplyGroupLine.quantity
                    it[stockSupplyGroupId] = stockSupplyGroup.stockSupplyGroupId
                }
            }
        }
        return getStockSupplyGroup(key!!)!!
    }

    suspend fun getAllStockSupplyGroups() : List<StockSupplyGroup>? = dbQuery {
        StockSupplyGroupsTable.selectAll().map {
            val stockSupplyGroupLines = StockSupplyGroupLinesTable.select { StockSupplyGroupLinesTable.id eq it[StockSupplyGroupsTable.stockSupplyGroupId] }.asIterable()
            toStockSupplyGroup(it, stockSupplyGroupLines)
        }
    }

    suspend fun getStockSupplyGroup(id: UUID): StockSupplyGroup? = dbQuery {
        val stockSupplyGroup = StockSupplyGroupsTable.select { (StockSupplyGroupsTable.stockSupplyGroupId eq id) }.firstOrNull()
        val stockSupplyGroupLines = StockSupplyGroupLinesTable.select { (StockSupplyGroupLinesTable.stockSupplyGroupId eq id) }.asIterable()

        toStockSupplyGroup(stockSupplyGroup!!, stockSupplyGroupLines)
    }

    private fun toStockSupplyGroup(row: ResultRow, overageLineRow: Iterable<ResultRow>): StockSupplyGroup {

        fun fillSupplyGroupLines(stockSupplyGroupLineRows: Iterable<ResultRow>) : List<StockSupplyGroupLine>? {
            val stockSupplyGroupLines = mutableListOf<StockSupplyGroupLine>()
            stockSupplyGroupLineRows.forEach {
                val stockSupplyGroupLine = StockSupplyGroupLine(stockLotId = it[StockSupplyGroupLinesTable.stockLotId],
                        quantity = it[StockSupplyGroupLinesTable.quantity], stockSupplyGroupLineId = it[StockSupplyGroupLinesTable.id])
                stockSupplyGroupLines.add(stockSupplyGroupLine)
            }
            return stockSupplyGroupLines
        }

        return StockSupplyGroup(
                stockSupplyGroupId = row[StockSupplyGroupsTable.stockSupplyGroupId],
                stockOverageId = row[StockSupplyGroupsTable.stockOverageId],
                stockDemandId = row[StockSupplyGroupsTable.stockDemandId],
                sourceProcessAreaId = row[StockSupplyGroupsTable.sourceProcessAreaId],
                destinationProcessAreaId = row[StockSupplyGroupsTable.destinationProcessAreaId],
                stockSupplyGroupLines = fillSupplyGroupLines(overageLineRow)!!
        )
    }

}

