rootProject.name = "kotlin-ktor-exposed-starter"

