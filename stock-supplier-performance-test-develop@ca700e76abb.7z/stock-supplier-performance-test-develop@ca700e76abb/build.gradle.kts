import com.bmuschko.gradle.docker.tasks.image.DockerBuildImage
import com.bmuschko.gradle.docker.tasks.image.DockerPushImage
import com.bmuschko.gradle.docker.tasks.image.Dockerfile
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile
import org.unbrokendome.gradle.plugins.helm.dsl.Tiller

val ktorVersion = "1.2.5"
val exposedVersion = "0.17.6"
val h2Version = "1.4.200"
val dockerRegistryUsername: String by project
val dockerRegistryPassword: String by project

plugins {
    kotlin("jvm") version "1.3.60"
    application
    java
    id("com.bmuschko.docker-remote-api") version "5.2.0"
    id("com.github.johnrengelman.shadow") version "5.1.0"
    id("org.unbroken-dome.helm-commands") version "0.4.4"
    id("org.unbroken-dome.helm") version "0.4.4"
    id("org.unbroken-dome.helm-publish") version "0.4.4"
    id("org.unbroken-dome.helm-releases") version "0.4.4"
}

java.sourceCompatibility = JavaVersion.VERSION_11
project.version = "1.0.100"

repositories {
    jcenter()
    mavenLocal()
    maven("https://jitpack.io")
}

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8")
    implementation("org.jetbrains.kotlin:kotlin-reflect")

    implementation("io.ktor:ktor-server-netty:$ktorVersion")
    implementation("io.ktor:ktor-jackson:$ktorVersion")
    implementation("io.ktor:ktor-websockets:$ktorVersion")
    implementation("io.ktor:ktor-network-tls:$ktorVersion")

    implementation("io.ktor:ktor-client-auth-jvm:$ktorVersion")
    implementation("io.ktor:ktor-client-apache:$ktorVersion")
    implementation("io.ktor:ktor-client-jackson:$ktorVersion")
    implementation("io.ktor:ktor-client-gson:$ktorVersion")
    implementation("io.ktor:ktor-client-core-jvm:$ktorVersion")

    implementation("io.ktor:ktor-html-builder:$ktorVersion")

    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.9.10")

    implementation("com.github.zensum:ktor-health-check:011a5a8")

    runtimeOnly("com.h2database:h2:$h2Version")
    implementation("org.jetbrains.exposed:exposed:$exposedVersion")
    implementation("com.zaxxer:HikariCP:3.3.1")

    implementation("org.apache.kafka:kafka-clients:1.1.0")

    implementation("ch.qos.logback:logback-classic:1.2.3")
    testImplementation("org.assertj:assertj-core:3.13.2")
    testImplementation("io.rest-assured:rest-assured:4.1.2")
    testImplementation("org.junit.jupiter:junit-jupiter-api:5.5.2")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:5.5.2")
}

application {
    mainClassName = "com.ktor.mock.MainKt"
}

tasks.withType<Jar> {
    manifest {
        attributes["Main-Class"] = application.mainClassName
    }
}

tasks.withType<Test> {
    useJUnitPlatform()
}

tasks.withType<KotlinCompile> {
    kotlinOptions {
        freeCompilerArgs = listOf("-Xjsr305=strict")
        jvmTarget = "11"
    }
}

docker {
    //    url.set("https://kube-storage:2376")
    registryCredentials {
        url.set("https://team2registry.azurecr.io")
        username.set(dockerRegistryUsername)
        password.set(dockerRegistryPassword)
    }
}

tasks.create("createDockerfile", Dockerfile::class) {
    from("docker.io/openjdk:11-jre-slim")
    addFile("kotlin-ktor-exposed-starter-${project.version}-all.jar", "app.jar")
    exposePort(8080, 8443)
    entryPoint("sh", "-c", "java -Xms1024m -Xmx1024m \$JAVA_OPTS -jar"
            + " -Djavax.net.ssl.trustStore=/etc/x509/keystore/truststore.jks"
            + " -Djavax.net.ssl.trustStorePassword=\$(cat /etc/x509/password/truststore)"
            + " /app.jar"
            + " -P:ktor.security.ssl.keyStorePassword=\$(cat /etc/x509/password/keystore)"
            + " -P:ktor.security.ssl.privateKeyPassword=\$(cat /etc/x509/password/keystore)")
    dependsOn(":assemble")
}

tasks.create("copyAppJar", Copy::class) {
    from("$buildDir/libs/${project.name}-${project.version}-all.jar")
    into("$buildDir/docker")
    dependsOn(":assemble")
}

tasks.create("buildDockerImage", DockerBuildImage::class) {
    tags.add("team2registry.azurecr.io/vanderlande/wpp/fm_ssu/team2-ktor-server:${project.version}")
    dependsOn(":createDockerfile", ":copyAppJar")
}

tasks.create("pushDockerImage", DockerPushImage::class) {
    imageName.set("team2registry.azurecr.io/vanderlande/wpp/fm_ssu/team2-ktor-server")
    tag.set("${project.version}")
    dependsOn(":buildDockerImage")
}

helm {
    home.set(file(System.getProperty("user.home") + "/.helm"))
    (this as ExtensionAware).configure<Tiller> {
        install.set(false)
    }
    charts {
        create("ktor-mock") {
            chartName.set("ktor-mock")
            chartVersion.set("0.1.0")
            sourceDir.set(file("src/main/helm"))
        }
    }
    releases {
        create("ktor-mock") {
            from(chart("ktor-mock"))
            namespace.set("performance-test")
            releaseName.set("performance-test-ktor-mock")
        }
    }
}
